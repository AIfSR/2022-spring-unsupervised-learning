This code is designed to train a logistic regression model on the synthetic trajectories given to us by Alina. 
Main.py is the main file that is run to train the LR model and report back the results. The data is loaded in,
split into train, cross validation, and test sets(60-20-20 respectively), and then the model is trained.
The accuracy results are calculated and printed out at the bottom.

To see an overview of the algorithm performance, and other useful information the document LRNotebook.pdf has
been created. It gives an overview of the same accuracy data but also provides useful information on the trajectories
that were incorrectly labeled and predicts some results about Dr. Mzyk's real data.
